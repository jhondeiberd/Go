package main

import (
	"Go/FinalProject/srcs/controllers/clientcontroller"
	"net/http"
)

func main() {
	http.HandleFunc("/", clientcontroller.Index)
	http.HandleFunc("/client", clientcontroller.Index)
	http.HandleFunc("/client/index", clientcontroller.Index)

	http.ListenAndServe(":8080", nil)
}
