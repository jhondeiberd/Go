package models

import (
	"Go/FinalProject/srcs/config"
	"Go/FinalProject/srcs/entities
)

type ClientModel struct {
}

func (*ClientModel) FindAll() ([]entities.Client, error) {
	db, err := config.GetDB()
	if err != nil {
		return nil, err
	} else {
		rows, err2 := db.Query("select * from client")
		if err2 != nil {
			return nil, err2
		} else {
			var clients []entities.Client
			for rows.Next() {
				var client entities.Client
				rows.Scan(&client.idClient, &client.firstName, &client.lastName, &client.email, &client.phoneNumber)
				clients = append(clients, client)
			}
			return clients, nil
		}
	}
}
