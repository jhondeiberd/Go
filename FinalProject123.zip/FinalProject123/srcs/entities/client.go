package entities

type Client struct {
	idClient    int64
	firstName   string
	lastName    string
	email       string
	phoneNumber int64
}
