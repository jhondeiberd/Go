package clientcontroller

import (
	"Go/FinalProject/srcs/models"
	"html/template"
	"net/http"
)

func Index(response http.ResponseWriter, request *http.Request) {
	var clientModel models.ClientModel
	clients, _ := clientModel.FindAll()
	data := map[string]interface{}{
		"clients": clients,
	}
	tmp, _ := template.ParseFiles("views/client/index.html")
	tmp.Execute(response, data)
}
